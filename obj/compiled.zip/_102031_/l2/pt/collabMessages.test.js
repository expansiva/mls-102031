/// <mls fileReference="_102031_/l2/pt/collabMessages.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
