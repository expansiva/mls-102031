/// <mls fileReference="_102031_/l2/www/pt/corporate.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
