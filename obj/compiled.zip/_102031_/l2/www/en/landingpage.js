/// <mls fileReference="_102031_/l2/www/en/landingpage.ts" enhancement="_102032_/l2/enhancementLandingPage" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLandingPage } from '_102032_/l2/collabLandingPage';
import { customElement } from 'lit/decorators.js';
let Landingpage102031 = class Landingpage102031 extends CollabLandingPage {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`www--en--landingpage-102031 .hero-bg{background:linear-gradient(rgba(10,15,30,0.85), rgba(10,15,30,0.98)),url('./assets/images/hero.avif');background-size:cover;background-position:center}www--en--landingpage-102031 .bg-dot-pattern{background-image:radial-gradient(#3b82f6 .8px, transparent .8px);background-size:32px 32px}www--en--landingpage-102031 .glass-card{background:rgba(255,255,255,0.03);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,0.05)}@keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}www--en--landingpage-102031 .ai-pill{background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.3);padding:6px 16px;border-radius:9999px;display:inline-flex;align-items:center;gap:8px;background-image:linear-gradient(90deg, #60a5fa 0%, #ffffff 50%, #60a5fa 100%);background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent;animation:shimmer 4s linear infinite}@keyframes hero-entrance{from{opacity:0;transform:translateY(-10px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}www--en--landingpage-102031 .animate-hero{animation:hero-entrance 1s ease-out forwards}www--en--landingpage-102031 .reveal{opacity:0;transform:translateY(30px);transition:all .8s cubic-bezier(.4, 0, .2, 1)}www--en--landingpage-102031 .reveal.active{opacity:1;transform:translateY(0)}`);
        this.sectionVideos = {
            title: "How It Works",
            real_product: {
                title: "Examples",
                videos: [
                    {
                        title: "PetShop",
                        description: "A simple pet shop application"
                    },
                    {
                        title: "TodoApp",
                        description: "A simple todo application"
                    },
                    {
                        title: "IndustryApp",
                        description: "A simple industry application"
                    },
                    {
                        title: "EcommerceApp",
                        description: "A simple ecommerce application"
                    }
                ]
            },
            customization: {
                title: "Easy Customization",
                videos: [
                    {
                        title: "Support multiple languages",
                        description: "Make the application ready for multiple languages and locales"
                    },
                    {
                        title: "Theming",
                        description: "Adapt themes and visual identity"
                    },
                    {
                        title: "Layout",
                        description: "Adapt the layout to different use cases and user preferences"
                    },
                    {
                        title: "Text Editor",
                        description: "Edit custom or AI-generated text with ease"
                    },
                    {
                        title: "Custom Components",
                        description: "Use or create custom components and swap them for alternative implementations"
                    }
                ]
            },
            business_fit: {
                title: "Adapted to Your Business",
                videos: [
                    {
                        title: "Business Rules",
                        description: "Create business rules, conditions, and automated actions"
                    },
                    {
                        title: "Expand with New Pages",
                        description: "Add new pages and connect them to the application menu"
                    },
                    {
                        title: "Access Control",
                        description: "Control access, permissions, and protected areas of the application"
                    },
                    {
                        title: "External Integrations",
                        description: "Integrate the application with other systems and APIs"
                    }
                ]
            },
            technical_architecture: {
                title: "Technical Foundation",
                videos: [
                    {
                        title: "Interface Technology",
                        description: "Inside the frontend architecture and technologies used"
                    },
                    {
                        title: "Application Backend",
                        description: "Inside the backend architecture and technologies used"
                    },
                    {
                        title: "Data Layer",
                        description: "Inside the data architecture and storage strategy"
                    },
                    {
                        title: "DevOps",
                        description: "Monitoring the live system, from errors to traffic and operational metrics"
                    }
                ]
            },
            ai_collaboration: {
                title: "AI Working With You",
                videos: [
                    {
                        title: "From Prompt to System",
                        description: "Using an initial prompt, refining requirements, and building complete systems"
                    },
                    {
                        title: "AI Customization",
                        description: "How AI helps customize the application after generation"
                    },
                    {
                        title: "AI Workflow",
                        description: "How to use AI to manage your workflow and automate tasks"
                    },
                    {
                        title: "AI in Automation",
                        description: "Using AI to execute business commands and operational actions"
                    }
                ]
            },
            performance: {
                title: "Performance and Scalability",
                videos: [
                    {
                        title: "Performance by Design",
                        description: "Designed for performance from the start"
                    },
                    {
                        title: "Scaling the System",
                        description: "Scaling the application to handle increasing load and data"
                    },
                    {
                        title: "Observability",
                        description: "Infrastructure and application monitoring in practice"
                    },
                    {
                        title: "Runtime Footprint",
                        description: "System resource usage and platform requirements in practice"
                    }
                ]
            }
        };
    }
    firstUpdated() {
        this.setEvents();
    }
    setEvents() {
        this.renderVideoSection(this.sectionVideos);
        this.setScrollEffects();
        this.setLoginEvent();
    }
    setScrollEffects() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, observerOptions);
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    }
    setLoginEvent() {
        const buttons = document.querySelectorAll('.btn-login');
        buttons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                //alert('Coming soon. Please check back shortly.');
                const params = {
                    type: 'iframeL7',
                    action: 'login'
                };
                window.parent.postMessage(params, '*');
            });
        });
    }
    _handleSignIn() {
        const params = {
            type: 'iframeL7',
            action: 'login'
        };
        window.parent.postMessage(params, '*');
    }
    renderVideoSection(sectionVideos) {
        const container = document.getElementById('video-groups-container');
        const mainTitle = document.getElementById('video-main-title');
        if (!container || !mainTitle) {
            console.error("Elementos de container de vídeo não encontrados.");
            return;
        }
        // Título Principal
        mainTitle.textContent = sectionVideos.title;
        // Função auxiliar para formatar a chave (ex: real_product -> Real Product)
        const formatKey = (key) => {
            return key.split('_')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ');
        };
        // Iterar sobre as entradas do objeto
        Object.entries(sectionVideos).forEach(([key, value]) => {
            // Pulamos a chave 'title' que é o título geral da seção
            if (key === 'title' || typeof value === 'string')
                return;
            const group = value;
            const groupTitle = formatKey(key);
            const groupDescription = group.title;
            const groupHtml = `
        <div class="reveal">
            <div class="mb-10">
                <div class="flex items-center gap-4 mb-2">
                    <h4 class="text-2xl font-black tracking-tighter text-slate-900 dark:text-white uppercase italic">
                        ${groupTitle}
                    </h4>
                    <div class="h-px bg-slate-100 dark:bg-slate-800 flex-grow"></div>
                </div>
                <p class="text-sm text-slate-500 font-medium">${groupDescription}</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                ${group.videos.map((video) => `
                    <div class="video-card group cursor-pointer" onclick="alert('Coming soon')">
                        <div class="relative aspect-video bg-slate-100 dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-800 mb-4 transition-all group-hover:border-blue-500/50 group-hover:shadow-lg group-hover:shadow-blue-500/10">
                            <div class="absolute inset-0 flex items-center justify-center">
                                <div class="w-12 h-12 bg-white/10 backdrop-blur-xl rounded-full flex items-center justify-center group-hover:scale-110 transition-transform border border-white/20">
                                    <svg class="w-5 h-5 text-blue-500 fill-current" viewBox="0 0 24 24">
                                        <path d="M8 5v14l11-7z"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <h5 class="font-bold text-sm mb-1 group-hover:text-blue-600 transition-colors">${video.title}</h5>
                        <p class="text-[11px] text-slate-500 leading-relaxed line-clamp-2">${video.description}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
            container.insertAdjacentHTML('beforeend', groupHtml);
        });
    }
};
Landingpage102031 = __decorate([
    customElement('www--en--landingpage-102031')
], Landingpage102031);
export { Landingpage102031 };
