/// <mls fileReference="_102031_/l2/www/en/landingpage.ts" enhancement="_102020_enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLandingPage } from '_102032_/l2/collabLandingPage';
import { customElement } from 'lit/decorators.js';
let Landingpage102031 = class Landingpage102031 extends CollabLandingPage {
    firstUpdated() {
        this.setEvents();
    }
    setEvents() {
        this.setScrollEffects();
        this.setLoginEvent();
    }
    setScrollEffects() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, observerOptions);
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    }
    setLoginEvent() {
        const buttons = document.querySelectorAll('.btn-login');
        buttons.forEach(button => {
            button.addEventListener('click', (event) => {
                event.preventDefault();
                alert('Coming soon. Please check back shortly.');
                /*
                const params = {
                    type: 'iframeL7',
                    action: 'login'
                };
                window.parent.postMessage(params, '*');
                */
            });
        });
    }
    _handleSignIn() {
        const params = {
            type: 'iframeL7',
            action: 'login'
        };
        window.parent.postMessage(params, '*');
    }
};
Landingpage102031 = __decorate([
    customElement('www--en--landingpage-102031')
], Landingpage102031);
export { Landingpage102031 };
