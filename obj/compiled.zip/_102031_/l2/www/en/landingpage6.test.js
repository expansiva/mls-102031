/// <mls fileReference="_102031_/l2/www/en/landingpage6.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
