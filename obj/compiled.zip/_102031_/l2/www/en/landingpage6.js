/// <mls fileReference="_102031_/l2/www/en/landingpage6.ts" enhancement="_102020_enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from '/_100554_/l2/collabPageElement.js';
import { customElement } from 'lit/decorators.js';
let Landingpage6102031 = class Landingpage6102031 extends CollabPageElement {
    initPage() {
        this.setEvents();
    }
    setEvents() {
        this.prepareEffects();
        this.prepareClickLoginButton();
    }
    prepareEffects() {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, observerOptions);
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    }
    prepareClickLoginButton() {
        const btnLogin = document.querySelector('#btnLogin');
        if (btnLogin) {
            btnLogin.addEventListener('click', this._handleSignIn);
        }
    }
    _handleSignIn() {
        const params = {
            type: 'iframeL7',
            action: 'login'
        };
        window.parent.postMessage(params, '*');
    }
};
Landingpage6102031 = __decorate([
    customElement('www--en--landingpage6-102031')
], Landingpage6102031);
export { Landingpage6102031 };
