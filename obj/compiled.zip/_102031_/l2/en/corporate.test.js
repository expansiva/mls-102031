/// <mls fileReference="_102031_/l2/en/corporate.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
