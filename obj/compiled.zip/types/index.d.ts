declare module "_102031_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102031_/l2/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/policy" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class PolicyEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102031_/l2/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/terms" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class TermsEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/aiFeatures.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/aiFeatures" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class AiFeaturesEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/collabMessages.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/collabMessages" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessagesEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/initial.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/initial" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial102031 extends CollabLitElement {
        private myMessage;
        private _handleSignIn;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/initial2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/initial2" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial2En102031 extends CollabLitElement {
        private myMessage;
        private _handleAction;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/landingpage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class LandingpageEn102031 extends CollabLitElement {
        private myMessage;
        private _handleWaitlist;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/landingpage2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage2" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class Landingpage2102031 extends CollabPageElement {
        initPage(): void;
        setEvents(): void;
        prepareClickLoginButton(): void;
        _handleSignIn(): void;
    }
}
declare module "_102031_/l2/www/en/landingpage6.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage6" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class Landingpage6102031 extends CollabPageElement {
        initPage(): void;
        setEvents(): void;
        prepareEffects(): void;
        prepareClickLoginButton(): void;
        _handleSignIn(): void;
    }
}
declare module "_102031_/l2/www/en/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/policy" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class PolicyEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/terms" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class TermsEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
