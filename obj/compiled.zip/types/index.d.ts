declare module "_102031_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102031_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102031_/l2/www/en/corporate.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/corporate.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/corporate" {
    import { CollabLandingPage } from '_102032_/l2/collabLandingPage';
    export class CollabMessagesEn102031 extends CollabLandingPage {
        firstUpdated(): void;
    }
}
declare module "_102031_/l2/www/en/index.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/index" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class Index102031 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_102031_/l2/www/en/landingpage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/landingpage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage" {
    import { CollabLandingPage } from '_102032_/l2/collabLandingPage';
    export class Landingpage102031 extends CollabLandingPage {
        firstUpdated(): void;
        setEvents(): void;
        setScrollEffects(): void;
        setLoginEvent(): void;
        _handleSignIn(): void;
    }
}
declare module "_102031_/l2/www/en/policy.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/policy" {
    import { LitElement } from 'lit';
    export class PolicyEn102031 extends LitElement {
        createRenderRoot(): this;
        firstUpdated(): void;
    }
}
declare module "_102031_/l2/www/en/terms.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/terms" {
    import { LitElement } from 'lit';
    export class TermsEn102031 extends LitElement {
        createRenderRoot(): this;
        firstUpdated(): void;
    }
}
