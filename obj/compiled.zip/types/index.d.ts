declare module "_102031_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102031_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            generateDist: string;
            variableVersion: string;
            start: string;
            liveView: string;
            preview: string;
            title: string;
            meta: string[];
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102031_/l2/www/en/about.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/about.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/index.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare class IndexPage1 {
    constructor();
    setEvents(): void;
    renderVideoSection(sectionVideos: SectionVideos): void;
    setScrollEffects(): void;
    setLoginEvent(): void;
    setRequestWaitingList(): void;
    closeModal(): void;
    openModal(): void;
    prepareWaitingListModal(): void;
}
interface Video {
    title: string;
    description: string;
}
interface VideoGroup {
    title: string;
    videos: Video[];
}
interface SectionVideos {
    title: string;
    [key: string]: string | VideoGroup;
}
declare module "_102031_/l2/www/en/policy.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/support.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/support.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare class SupportPage {
    constructor();
    setEvents(): void;
    setScrollEffects(): void;
    setLiveChatButtonEvent(): void;
    handleLiveChatButtonClick(): void;
}
declare module "_102031_/l2/www/en/terms.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
